import { RouterProvider, useRouter } from "./components/akira/NavigationContext";
import { Nav } from "./components/akira/Nav";
import { HorizontalPage } from "./components/akira/Horizontal";
import { Footer } from "./components/akira/Sections";
import { BikeDetailPage } from "./components/akira/BikeDetailPage";
import { ComprarPage } from "./components/akira/ComprarPage";

function AppContent() {
  const { path } = useRouter();

  if (path.startsWith("/comprar/")) {
    const slug = path.replace("/comprar/", "").split("/")[0] || "akr-1390";
    return <ComprarPage slug={slug} />;
  }

  if (path.startsWith("/motos/")) {
    const slug = path.replace("/motos/", "").split("/")[0] || "akr-1390";
    return <BikeDetailPage slug={slug} />;
  }

  return (
    <main
      id="top"
      className="min-h-screen bg-background text-foreground selection:bg-primary selection:text-primary-foreground"
    >
      <Nav />
      <HorizontalPage />
      <Footer />
    </main>
  );
}

export default function App() {
  return (
    <RouterProvider>
      <AppContent />
    </RouterProvider>
  );
}
