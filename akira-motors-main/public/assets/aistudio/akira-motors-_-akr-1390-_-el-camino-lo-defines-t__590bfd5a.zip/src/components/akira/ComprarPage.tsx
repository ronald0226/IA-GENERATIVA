import { useState, type FormEvent } from "react";
import { ArrowLeft, Rocket, X } from "lucide-react";
import { bikes, cities, colors, paymentMethods, logoImg } from "./data";
import { AkButton, Eyebrow, HudBracket } from "./ui";
import { useRouter } from "./NavigationContext";
import { validateBuyerForm, type BuyerFormInput } from "./logic";

export function ComprarPage({ slug }: { slug: string }) {
  const { navigate } = useRouter();
  const [openModal, setOpenModal] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const [form, setForm] = useState<BuyerFormInput & { color: string; pago: string }>({
    nombre: "",
    documento: "",
    email: "",
    telefono: "",
    ciudad: "",
    direccion: "",
    color: colors[0],
    pago: paymentMethods[0],
    terminos: false,
  });

  const bike = bikes.find((b) => b.slug === slug) || bikes[0];

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const validationErrors = validateBuyerForm(form);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    setErrors({});
    setOpenModal(true);
  };

  const inputClass =
    "w-full rounded-lg border-2 border-input bg-card px-4 py-3 text-sm text-foreground outline-none focus:border-primary transition-colors font-medium";

  return (
    <main className="min-h-screen bg-background text-foreground selection:bg-primary selection:text-primary-foreground cyber-grid">
      {/* Header */}
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6 border-b border-border/40">
        <button
          type="button"
          onClick={() => navigate("/")}
          className="flex items-center gap-2 cursor-pointer"
        >
          <img
            src={logoImg}
            alt="Akira Motors"
            className="akira-brand-logo h-8 w-auto object-contain"
          />
          <span className="font-display font-black text-sm tracking-wider text-foreground">
            AKIRA <span className="text-primary font-bold">MOTORS</span>
          </span>
        </button>
        <button
          type="button"
          onClick={() => navigate(`/motos/${bike.slug}`)}
          className="flex items-center gap-2 text-xs sm:text-sm font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
        >
          <ArrowLeft size={16} /> Volver a la moto
        </button>
      </header>

      {/* Main Container */}
      <div className="mx-auto grid max-w-6xl gap-10 px-6 pb-20 lg:grid-cols-[1fr_1.3fr] pt-6">
        {/* Left Aside: Order Summary */}
        <aside className="h-fit rounded-xl border-2 border-border bg-card p-6 shadow-md relative lg:sticky lg:top-6">
          <HudBracket />
          <Eyebrow kanji="注文">Tu pedido</Eyebrow>
          <img
            src={bike.img}
            alt={`Moto ${bike.name}`}
            className="w-full object-contain max-h-[260px] my-2"
          />
          <h1 className="mt-4 font-display text-3xl font-black uppercase">
            {bike.name}
          </h1>
          <p className="text-muted-foreground mt-1">
            {bike.cat} · {bike.cc} · {bike.hp}
          </p>
          <div className="mt-6 flex justify-between items-center border-t border-border pt-4">
            <span className="text-muted-foreground text-sm uppercase tracking-wider">
              Total
            </span>
            <span className="font-display text-2xl font-black text-foreground">
              {bike.price}
            </span>
          </div>
        </aside>

        {/* Right Form: Buyer Details */}
        <form onSubmit={handleSubmit} noValidate className="space-y-5">
          <Eyebrow>Datos del comprador</Eyebrow>

          <div className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className="block mb-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Nombre completo
              </label>
              <input
                name="nombre"
                value={form.nombre}
                onChange={(e) =>
                  setForm({ ...form, nombre: e.target.value })
                }
                maxLength={100}
                placeholder="Nombre completo"
                className={inputClass}
              />
              {errors.nombre && (
                <span className="mt-1 block text-xs text-destructive">
                  {errors.nombre}
                </span>
              )}
            </div>

            <div>
              <label className="block mb-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Cédula
              </label>
              <input
                name="documento"
                value={form.documento}
                onChange={(e) =>
                  setForm({ ...form, documento: e.target.value })
                }
                inputMode="numeric"
                maxLength={12}
                placeholder="Número de cédula"
                className={inputClass}
              />
              {errors.documento && (
                <span className="mt-1 block text-xs text-destructive">
                  {errors.documento}
                </span>
              )}
            </div>

            <div>
              <label className="block mb-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Correo
              </label>
              <input
                name="email"
                type="email"
                value={form.email}
                onChange={(e) =>
                  setForm({ ...form, email: e.target.value })
                }
                maxLength={255}
                placeholder="correo@ejemplo.com"
                className={inputClass}
              />
              {errors.email && (
                <span className="mt-1 block text-xs text-destructive">
                  {errors.email}
                </span>
              )}
            </div>

            <div>
              <label className="block mb-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Teléfono
              </label>
              <input
                name="telefono"
                type="tel"
                value={form.telefono}
                onChange={(e) =>
                  setForm({ ...form, telefono: e.target.value })
                }
                maxLength={15}
                placeholder="+57 300 000 0000"
                className={inputClass}
              />
              {errors.telefono && (
                <span className="mt-1 block text-xs text-destructive">
                  {errors.telefono}
                </span>
              )}
            </div>

            <div>
              <label className="block mb-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Ciudad de entrega
              </label>
              <select
                name="ciudad"
                value={form.ciudad}
                onChange={(e) =>
                  setForm({ ...form, ciudad: e.target.value })
                }
                className={inputClass}
              >
                <option value="" disabled>
                  Elige…
                </option>
                {cities.map((city) => (
                  <option key={city} value={city}>
                    {city}
                  </option>
                ))}
              </select>
              {errors.ciudad && (
                <span className="mt-1 block text-xs text-destructive">
                  {errors.ciudad}
                </span>
              )}
            </div>

            <div>
              <label className="block mb-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Dirección
              </label>
              <input
                name="direccion"
                value={form.direccion}
                onChange={(e) =>
                  setForm({ ...form, direccion: e.target.value })
                }
                maxLength={200}
                placeholder="Dirección de entrega"
                className={inputClass}
              />
              {errors.direccion && (
                <span className="mt-1 block text-xs text-destructive">
                  {errors.direccion}
                </span>
              )}
            </div>

            <div>
              <label className="block mb-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Color
              </label>
              <select
                name="color"
                value={form.color}
                onChange={(e) =>
                  setForm({ ...form, color: e.target.value })
                }
                className={inputClass}
              >
                {colors.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block mb-1.5 text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                Forma de pago
              </label>
              <select
                name="pago"
                value={form.pago}
                onChange={(e) =>
                  setForm({ ...form, pago: e.target.value })
                }
                className={inputClass}
              >
                {paymentMethods.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="flex items-center gap-3 text-sm cursor-pointer select-none">
              <input
                type="checkbox"
                name="terminos"
                checked={form.terminos}
                onChange={(e) =>
                  setForm({ ...form, terminos: e.target.checked })
                }
                className="h-4 w-4 rounded border-border accent-primary cursor-pointer"
              />
              <span className="text-muted-foreground">
                Acepto los términos y condiciones
              </span>
            </label>
            {errors.terminos && (
              <span className="mt-1 block text-xs text-destructive">
                {errors.terminos}
              </span>
            )}
          </div>

          <AkButton type="submit" className="w-full py-3.5">
            Finalizar compra
          </AkButton>
        </form>
      </div>

      {/* Success Dialog Modal */}
      {openModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-2xl rounded-2xl border-2 border-primary bg-card p-10 text-center shadow-2xl sm:p-14 animate-in zoom-in-95">
            <HudBracket />
            <button
              type="button"
              aria-label="Cerrar modal"
              onClick={() => setOpenModal(false)}
              className="absolute right-4 top-4 rounded-sm text-muted-foreground transition-opacity hover:opacity-100 cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>

            <Rocket className="mx-auto text-primary" size={56} />
            <h2 className="font-display text-[clamp(2rem,5vw,3.5rem)] font-black uppercase leading-none mt-4 text-foreground">
              ¡Gracias por tu compra!
            </h2>
            <p className="mt-3 text-xl text-foreground">
              Nuestras motos estarán disponibles en el año{" "}
              <span className="font-black text-primary">2400</span>.
            </p>

            <AkButton
              className="mx-auto mt-6 px-8"
              onClick={() => navigate("/")}
            >
              Volver al home
            </AkButton>
          </div>
        </div>
      )}
    </main>
  );
}
