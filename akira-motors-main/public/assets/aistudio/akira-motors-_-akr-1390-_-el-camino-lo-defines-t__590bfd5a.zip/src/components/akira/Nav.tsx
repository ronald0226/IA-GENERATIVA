import { useEffect, useState } from "react";
import { Moon, Sun, Menu, X, Volume2, VolumeX } from "lucide-react";
import { AkButton } from "./ui";
import { goTo } from "./Horizontal";
import { logoImg } from "./data";
import { useRouter } from "./NavigationContext";
import { sound } from "./engineSound";

const links = [
  ["AKR 1390", "akr1390"],
  ["Catálogo", "catalogo"],
  ["Experiencia", "experiencia"],
  ["Concesionarios", "contacto"],
];

export function Nav() {
  const [light, setLight] = useState(false);
  const [open, setOpen] = useState(false);
  const [muted, setMuted] = useState(sound.getMuted());
  const { path, navigate } = useRouter();

  useEffect(() => {
    document.documentElement.classList.toggle("light", light);
  }, [light]);

  const handleNavClick = (panelId: string) => {
    setOpen(false);
    if (path !== "/") {
      navigate("/", panelId);
    } else {
      goTo(panelId);
    }
  };

  const handleSoundToggle = () => {
    const isNowMuted = sound.toggleMute();
    setMuted(isNowMuted);
  };

  return (
    <header className="fixed inset-x-0 top-4 z-50 px-4">
      <nav className="mx-auto flex max-w-6xl items-center justify-between rounded-xl border border-border bg-background/85 px-5 py-3 backdrop-blur-xl shadow-lg shadow-black/15">
        <a
          href="#inicio"
          onClick={(e) => {
            e.preventDefault();
            handleNavClick("inicio");
          }}
          className="flex items-center gap-2.5 font-display text-xl font-black tracking-tight"
        >
          <img
            src={logoImg}
            alt="Akira Motors"
            className="akira-brand-logo h-7 w-auto object-contain transition-all"
          />
          <div className="flex flex-col">
            <span className="font-display font-black tracking-wider text-sm sm:text-base text-foreground leading-none">
              AKIRA <span className="text-primary font-bold">MOTORS</span>
            </span>
            <span className="text-[9px] font-mono tracking-[0.25em] text-muted-foreground font-semibold">
              アキラ · NEO TOKYO
            </span>
          </div>
        </a>

        <ul className="hidden items-center gap-7 lg:flex">
          {links.map(([label, panelId]) => (
            <li key={panelId}>
              <a
                href={`#${panelId}`}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(panelId);
                }}
                className="text-xs font-bold uppercase tracking-wider text-muted-foreground transition-colors hover:text-foreground cursor-pointer"
              >
                {label}
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-2">
          {/* Cyberpunk Audio Engine rev toggle */}
          <button
            type="button"
            aria-label={muted ? "Activar sonido de motor" : "Silenciar sonido de motor"}
            title={muted ? "Activar sonido de motor" : "Silenciar sonido de motor"}
            onClick={handleSoundToggle}
            className="grid h-10 w-10 place-items-center rounded-lg border border-border hover:border-primary text-foreground transition-colors cursor-pointer"
          >
            {muted ? (
              <VolumeX size={17} className="text-muted-foreground" />
            ) : (
              <Volume2 size={17} className="text-primary animate-pulse" />
            )}
          </button>

          {/* Theme switcher */}
          <button
            type="button"
            aria-label="Cambiar tema de color"
            onClick={() => setLight((v) => !v)}
            className="grid h-10 w-10 place-items-center rounded-lg border border-border hover:border-primary text-foreground transition-colors cursor-pointer"
          >
            {light ? <Moon size={17} /> : <Sun size={17} />}
          </button>

          <AkButton
            onClick={() => handleNavClick("contacto")}
            className="hidden sm:inline-flex px-4 py-2 text-xs"
          >
            Agenda tu Test Drive
          </AkButton>

          <button
            type="button"
            aria-label="Menú principal"
            onClick={() => setOpen((v) => !v)}
            className="grid h-10 w-10 place-items-center rounded-lg border border-border text-foreground hover:border-primary lg:hidden cursor-pointer"
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </nav>

      {open && (
        <ul className="mx-auto mt-2 max-w-6xl space-y-1.5 rounded-xl border border-border bg-background/95 p-4 shadow-2xl backdrop-blur-xl lg:hidden">
          {links.map(([label, panelId]) => (
            <li key={panelId}>
              <a
                href={`#${panelId}`}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(panelId);
                }}
                className="block rounded-lg px-4 py-3 text-sm font-bold uppercase tracking-wider text-foreground hover:bg-muted transition-colors cursor-pointer"
              >
                {label}
              </a>
            </li>
          ))}
          <li className="pt-2">
            <AkButton
              onClick={() => handleNavClick("contacto")}
              className="w-full py-3 text-xs"
            >
              Agenda tu Test Drive
            </AkButton>
          </li>
        </ul>
      )}
    </header>
  );
}
