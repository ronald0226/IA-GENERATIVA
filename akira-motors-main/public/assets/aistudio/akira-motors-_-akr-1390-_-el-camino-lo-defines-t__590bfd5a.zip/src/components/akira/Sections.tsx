import { useState, useEffect } from "react";
import {
  ChevronDown,
  GitCompare,
  Check,
  Instagram,
  Youtube,
  Facebook,
  MapPin,
  ArrowRight,
  ShieldCheck,
  Gauge,
  Sparkles,
  Zap,
  Flame,
  Radio,
  Cpu,
} from "lucide-react";
import { AkButton, Eyebrow, SectionTitle, HudBracket } from "./ui";
import { bikes, categories, cities, logoImg, roadImg } from "./data";
import { cn } from "@/src/lib/utils";
import { useRouter } from "./NavigationContext";
import { goTo } from "./Horizontal";
import { sound } from "./engineSound";

const specs = [
  {
    k: "Cilindrada",
    v: "1390",
    u: "cc",
    d: "Bicilíndrico en V a 75°, refrigerado por líquido de última generación con cuerpos de inyección Keihin de 56 mm.",
  },
  {
    k: "Potencia",
    v: "180",
    u: "HP",
    d: "A 10.000 rpm. Empuje lineal, despiadado y continuo hasta el corte con sincronizador quickshifter bidireccional.",
  },
  {
    k: "Torque",
    v: "145",
    u: "Nm",
    d: "A 8.000 rpm. Aceleración visceral que te pega al manillar en cualquier marcha y régimen.",
  },
  {
    k: "Peso",
    v: "199",
    u: "kg",
    d: "En orden de marcha sin combustible. Relación peso-potencia inigualable en chasis trellis cromo-molibdeno.",
  },
  {
    k: "Modos de manejo",
    v: "4",
    u: "modos",
    d: "Rain · Street · Sport · Track con telemetría en tiempo real y telemetría de ángulos de inclinación en pantalla TFT de 5\".",
  },
];

const HOTSPOTS = [
  {
    id: "motor",
    name: "01. Motor V-Twin 75°",
    tag: "1390 cc · 180 HP",
    desc: "Bicilíndrico con doble inyector ride-by-wire. 145 Nm de empuje instantáneo.",
    pos: "top-[58%] left-[45%]",
  },
  {
    id: "frenos",
    name: "02. Frenos Brembo Stylema",
    tag: "320 mm · Bosch 10.3",
    desc: "Pinzas radiales monobloque con Cornering ABS y modo Supermoto desconectable.",
    pos: "top-[64%] left-[72%]",
  },
  {
    id: "suspension",
    name: "03. Suspensión WP APEX",
    tag: "43 mm Invertida",
    desc: "Barras invertidas semiactivas con ajuste milimétrico en compresión y rebote.",
    pos: "top-[40%] left-[64%]",
  },
  {
    id: "radar",
    name: "04. Radar Frontal ADAS",
    tag: "30–180 km/h",
    desc: "Control crucero adaptativo por radar frontal con distancia de seguridad automática.",
    pos: "top-[32%] left-[78%]",
  },
  {
    id: "cockpit",
    name: "05. Cockpit TFT 5\"",
    tag: "Telemetría Akira",
    desc: "Instrumentación digital HUD, conectividad Bluetooth, GPS turn-by-turn y telemetría.",
    pos: "top-[28%] left-[52%]",
  },
];

export function Specs() {
  const [open, setOpen] = useState(0);
  const [activeTab, setActiveTab] = useState<"specs" | "hotspots">("specs");
  const [selectedHotspot, setSelectedHotspot] = useState(0);
  const [rpm, setRpm] = useState(1400);
  const [isRevving, setIsRevving] = useState(false);

  const heroBike = bikes[0];

  const handleRev = () => {
    sound.playEngineRev(1.0);
    setIsRevving(true);
    setRpm(10400);
    setTimeout(() => {
      setRpm(1400);
      setIsRevving(false);
    }, 1200);
  };

  return (
    <div className="mx-auto w-full max-w-6xl px-6 py-20 lg:px-16 lg:py-0">
      <div className="grid gap-10 lg:grid-cols-[1.1fr_1.3fr] items-center">
        <div>
          <Eyebrow kanji="仕様">Ficha técnica · AKR 1390</Eyebrow>
          <SectionTitle>Siente la potencia</SectionTitle>
          <p className="mt-5 max-w-md text-base sm:text-lg text-muted-foreground leading-relaxed font-medium">
            Rendimiento de competición calibrado para quienes no se conforman con lo ordinario.
            Cada cifra es una descarga de adrenalina al girar el puño.
          </p>

          {/* Interactive Cyberpunk Throttle & RPM Gauge */}
          <div className="mt-6 rounded-xl border-2 border-border bg-card p-4 shadow-sm relative overflow-hidden">
            <HudBracket />
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase tracking-widest text-primary font-bold flex items-center gap-1.5">
                  <Radio size={13} className="animate-pulse" /> Telemetría V-Twin
                </span>
                <p className="font-display text-2xl font-black text-foreground tabular-nums">
                  {rpm.toLocaleString()}{" "}
                  <span className="text-xs font-mono text-muted-foreground font-semibold">RPM</span>
                </p>
              </div>

              <button
                type="button"
                onClick={handleRev}
                className={cn(
                  "clip-cyber-corner inline-flex items-center gap-2 px-4 py-2.5 text-xs font-black uppercase tracking-wider text-primary-foreground transition-all duration-200 cursor-pointer shadow-md select-none",
                  isRevving
                    ? "bg-primary-deep scale-95 shadow-[0_0_20px_var(--color-primary)]"
                    : "bg-primary hover:bg-primary-deep"
                )}
              >
                <Flame size={15} className={isRevving ? "animate-bounce" : ""} />
                {isRevving ? "Acelerando..." : "Acelerar Motor"}
              </button>
            </div>

            {/* Tachometer bar */}
            <div className="mt-3 h-2 w-full bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-emerald-500 via-yellow-500 to-primary transition-all duration-300"
                style={{ width: `${Math.min(100, (rpm / 11000) * 100)}%` }}
              />
            </div>
            <div className="mt-1 flex justify-between text-[9px] font-mono text-muted-foreground font-bold">
              <span>0 RPM</span>
              <span>5.000 (PAR MÁX)</span>
              <span className="text-primary">10.500 (CORTE)</span>
            </div>
          </div>

          {/* Trust badges with high contrast */}
          <div className="mt-6 flex flex-wrap items-center gap-4 text-xs font-bold uppercase tracking-wider text-foreground">
            <span className="flex items-center gap-1.5 text-primary">
              <ShieldCheck size={16} /> 3 años garantía oficial
            </span>
            <span className="flex items-center gap-1.5 text-foreground">
              <Gauge size={16} className="text-primary" /> Telemetría integrada
            </span>
            <span className="flex items-center gap-1.5 text-foreground">
              <Zap size={16} className="text-primary" /> Modo Supermoto
            </span>
          </div>

          {/* View Mode Toggle: Modular specs vs Hotspots */}
          <div className="mt-6 flex gap-2">
            <button
              type="button"
              onClick={() => {
                sound.playMechanicalClick();
                setActiveTab("specs");
              }}
              className={cn(
                "clip-cyber-corner px-4 py-2 text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer",
                activeTab === "specs"
                  ? "bg-primary text-primary-foreground"
                  : "bg-card border border-border text-muted-foreground hover:text-foreground"
              )}
            >
              Ficha Modular
            </button>
            <button
              type="button"
              onClick={() => {
                sound.playMechanicalClick();
                setActiveTab("hotspots");
              }}
              className={cn(
                "clip-cyber-corner px-4 py-2 text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer flex items-center gap-1.5",
                activeTab === "hotspots"
                  ? "bg-primary text-primary-foreground"
                  : "bg-card border border-border text-muted-foreground hover:text-foreground"
              )}
            >
              <Cpu size={14} /> Hotspots de Ingeniería
            </button>
          </div>
        </div>

        {/* Tab 1: Ficha Modular */}
        {activeTab === "specs" ? (
          <ul className="divide-y divide-border border-2 border-border bg-card rounded-xl p-4 sm:p-5 shadow-md">
            {specs.map((s, i) => (
              <li key={s.k}>
                <button
                  type="button"
                  onClick={() => {
                    sound.playMechanicalClick();
                    setOpen(i === open ? -1 : i);
                  }}
                  className="flex w-full items-center justify-between py-4 text-left cursor-pointer group"
                >
                  <span className="text-xs sm:text-sm font-bold uppercase tracking-widest text-muted-foreground group-hover:text-foreground transition-colors">
                    {s.k}
                  </span>
                  <span className="flex items-center gap-4">
                    <span className="font-display text-2xl sm:text-3xl font-black text-foreground">
                      {s.v}
                      <span className="ml-1 text-sm font-bold text-primary">
                        {s.u}
                      </span>
                    </span>
                    <ChevronDown
                      size={20}
                      className={cn(
                        "transition-transform duration-300 text-muted-foreground group-hover:text-primary",
                        open === i && "rotate-180 text-primary"
                      )}
                    />
                  </span>
                </button>
                <div
                  className={cn(
                    "grid transition-all duration-300",
                    open === i ? "grid-rows-[1fr] pb-4 opacity-100" : "grid-rows-[0fr] opacity-0"
                  )}
                >
                  <p className="overflow-hidden text-sm font-medium text-muted-foreground leading-relaxed">
                    {s.d}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          /* Tab 2: Hotspots interactivos de ingeniería en la AKR 1390 */
          <div className="rounded-xl border-2 border-border bg-card p-5 shadow-md relative overflow-hidden">
            <HudBracket />
            <div className="relative aspect-[16/10] w-full flex items-center justify-center overflow-hidden rounded-lg bg-background/50 border border-border">
              <img
                src={heroBike.img}
                alt="AKR 1390 Hotspots"
                className="h-full w-full object-contain p-2"
              />

              {/* Hotspot pins */}
              {HOTSPOTS.map((h, idx) => (
                <button
                  key={h.id}
                  type="button"
                  onClick={() => {
                    sound.playMechanicalClick();
                    setSelectedHotspot(idx);
                  }}
                  aria-label={`Ver hotspot ${h.name}`}
                  className={cn(
                    "absolute -translate-x-1/2 -translate-y-1/2 flex items-center justify-center rounded-full transition-all duration-300 cursor-pointer shadow-lg",
                    h.pos,
                    selectedHotspot === idx
                      ? "h-8 w-8 bg-primary text-primary-foreground ring-4 ring-primary/30 scale-110"
                      : "h-6 w-6 bg-background/90 text-foreground border-2 border-primary hover:scale-110"
                  )}
                >
                  <span className="text-[10px] font-mono font-black">{idx + 1}</span>
                </button>
              ))}
            </div>

            {/* Selected Hotspot Detail Card */}
            {HOTSPOTS[selectedHotspot] && (
              <div className="mt-4 p-4 rounded-lg bg-background border border-border">
                <div className="flex items-center justify-between">
                  <span className="font-display text-sm font-black text-foreground">
                    {HOTSPOTS[selectedHotspot].name}
                  </span>
                  <span className="text-xs font-mono font-bold text-primary">
                    {HOTSPOTS[selectedHotspot].tag}
                  </span>
                </div>
                <p className="mt-2 text-xs sm:text-sm text-muted-foreground leading-relaxed">
                  {HOTSPOTS[selectedHotspot].desc}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export function Catalog() {
  const [cat, setCat] = useState<(typeof categories)[number]>("Todas");
  const [compare, setCompare] = useState<string[]>([]);
  const { navigate } = useRouter();

  const list = bikes.filter((b) => cat === "Todas" || b.cat === cat);

  return (
    <div className="w-full py-20 lg:pt-16 lg:pb-0">
      <div className="mx-auto max-w-6xl px-6">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div>
            <Eyebrow kanji="製品カタログ">Catálogo Oficial · Akira Motors</Eyebrow>
            <SectionTitle>Elige tu territorio</SectionTitle>
          </div>
          
          {/* Cyberpunk Filter Tabs with High Contrast */}
          <div className="flex flex-wrap gap-2">
            {categories.map((c) => (
              <button
                type="button"
                key={c}
                onClick={() => {
                  sound.playMechanicalClick();
                  setCat(c);
                }}
                className={cn(
                  "clip-cyber-corner border-2 px-4 py-2 text-xs sm:text-sm font-bold uppercase tracking-wider transition-all cursor-pointer",
                  cat === c
                    ? "border-primary bg-primary text-primary-foreground shadow-md shadow-primary/20"
                    : "border-border bg-card text-foreground hover:border-primary hover:text-primary"
                )}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {list.map((b) => {
            const on = compare.includes(b.name);
            return (
              <article
                key={b.name}
                onMouseEnter={() => sound.playHoverRumble()}
                className="group relative overflow-hidden rounded-xl border-2 border-border bg-card transition-all duration-300 hover:border-primary hover:shadow-xl flex flex-col justify-between"
              >
                <div
                  onClick={() => navigate(`/motos/${b.slug}`)}
                  className="relative block aspect-[4/3] overflow-hidden bg-background/50 cursor-pointer"
                >
                  <img
                    src={b.img}
                    alt={`Moto ${b.name}`}
                    loading="lazy"
                    className="h-full w-full object-contain p-4 transition-transform duration-500 group-hover:scale-105"
                  />
                  
                  {/* Category Pill with 100% High Contrast */}
                  <span className="absolute left-3 top-3 rounded-md bg-background px-2.5 py-1 text-[11px] font-black uppercase tracking-wider border border-border text-foreground shadow-xs">
                    {b.cat}
                  </span>

                  <div className="absolute inset-x-0 bottom-0 flex translate-y-full justify-around bg-background/95 py-2.5 backdrop-blur transition-transform duration-300 group-hover:translate-y-0 border-t border-border">
                    {[b.cc, b.hp, b.kg].map((v) => (
                      <span
                        key={v}
                        className="font-display text-xs font-black text-foreground"
                      >
                        {v}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex flex-col items-start gap-3 p-4">
                  <div className="w-full">
                    <h3 className="font-display text-lg font-black text-foreground leading-tight">
                      {b.name}
                    </h3>
                    <p className="text-sm font-black text-primary mt-1">{b.price}</p>
                    <p className="mt-1 text-xs text-muted-foreground line-clamp-1 font-medium">
                      {b.tagline}
                    </p>
                  </div>

                  <div className="flex w-full flex-wrap gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => navigate(`/motos/${b.slug}`)}
                      className="clip-cyber-corner flex-1 bg-primary px-3 py-2 text-center text-xs font-bold uppercase tracking-wider text-primary-foreground hover:bg-primary-deep transition-colors cursor-pointer"
                    >
                      Ver Detalles
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        sound.playMechanicalClick();
                        setCompare((c) =>
                          on ? c.filter((n) => n !== b.name) : [...c, b.name].slice(-2)
                        );
                      }}
                      className={cn(
                        "clip-cyber-corner flex items-center gap-1.5 border-2 px-3 py-2 text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer",
                        on
                          ? "border-primary bg-primary/10 text-primary"
                          : "border-border text-muted-foreground hover:border-foreground hover:text-foreground"
                      )}
                    >
                      {on ? <Check size={14} /> : <GitCompare size={14} />} Comparar
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>

        {compare.length === 2 && (
          <div className="mt-6 grid grid-cols-3 gap-4 rounded-xl border-2 border-primary bg-card p-5 text-sm backdrop-blur-md animate-in fade-in shadow-xl">
            <div className="flex flex-col justify-center">
              <span className="text-xs uppercase tracking-wider text-primary font-black">
                Comparación directa
              </span>
              <p className="text-xs text-muted-foreground font-medium">Ficha técnica frente a frente</p>
            </div>
            {compare.map((n) => {
              const b = bikes.find((x) => x.name === n)!;
              return (
                <div key={n} className="border-l border-border pl-4">
                  <p className="font-display font-black text-foreground">{n}</p>
                  <p className="text-xs text-primary font-black mt-0.5">{b.price}</p>
                  <p className="text-xs text-muted-foreground mt-1 font-medium">
                    {b.cc} · {b.hp} · {b.kg}
                  </p>
                  <button
                    type="button"
                    onClick={() => navigate(`/motos/${b.slug}`)}
                    className="mt-2 text-xs text-primary underline underline-offset-4 font-bold hover:text-primary-deep cursor-pointer"
                  >
                    Ficha completa →
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

export function Brand() {
  return (
    <div className="relative flex h-full min-h-[100svh] w-full items-center overflow-hidden py-20 lg:min-h-0 lg:py-0 cyber-grid">
      <img
        src={roadImg}
        alt=""
        aria-hidden
        loading="lazy"
        className="absolute inset-0 h-full w-full object-cover opacity-10 dark:opacity-25"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-background via-background/70 to-background" />
      
      <div className="relative mx-auto max-w-4xl px-6 text-center">
        <Eyebrow kanji="哲学・探検家">ADN Akira · Arquetipo El Explorador</Eyebrow>
        
        <p className="font-display text-[clamp(1.7rem,3.8vw,3.2rem)] font-black uppercase leading-tight text-foreground">
          No construimos vehículos para encajar en la ciudad. Diseñamos{" "}
          <span className="text-primary underline decoration-primary/40 underline-offset-8">
            máquinas para redibujar el mapa.
          </span>
        </p>

        <p className="mx-auto mt-6 max-w-2xl text-base sm:text-lg font-medium text-muted-foreground leading-relaxed">
          En Akira Motors, cada curva es un reto y cada aceleración es una declaración de libertad.
          La ingeniería japonesa de precisión se une a la audacia del diseño contemporáneo.
          La potencia está ahí, el control es tuyo. Explora lo inexplorado.
        </p>

        {/* High Contrast Stat Indicators */}
        <div className="mt-10 grid grid-cols-3 gap-6 rounded-xl border-2 border-border bg-card p-6 shadow-lg relative">
          <HudBracket />
          {[
            ["12", "años en ruta"],
            ["48", "países"],
            ["210K", "pilotos"],
          ].map(([n, l]) => (
            <div key={l}>
              <p className="font-display text-3xl sm:text-5xl font-black text-foreground">
                {n}
              </p>
              <p className="text-xs uppercase tracking-widest text-muted-foreground mt-2 font-bold">
                {l}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function Contact() {
  const [step, setStep] = useState(0);
  const [model, setModel] = useState("AKR 1390");
  const [city, setCity] = useState("Bogotá");
  const [type, setType] = useState("Test Drive");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  const inputClass =
    "w-full rounded-lg border-2 border-input bg-card px-4 py-3 text-sm text-foreground outline-none focus:border-primary transition-colors font-medium";

  return (
    <div className="mx-auto w-full max-w-3xl px-6 py-20 lg:py-0">
      <div>
        <Eyebrow kanji="正規ディーラー">Concesionarios y Test Drive</Eyebrow>
        <SectionTitle>Configura tu ruta</SectionTitle>

        <div className="mt-6 flex gap-2">
          {[0, 1].map((i) => (
            <span
              key={i}
              className={cn(
                "h-1.5 flex-1 rounded-full transition-colors",
                step >= i ? "bg-primary" : "bg-border"
              )}
            />
          ))}
        </div>

        {sent ? (
          <div className="mt-8 rounded-xl border-2 border-primary bg-card p-8 text-center shadow-xl animate-in fade-in relative">
            <HudBracket />
            <div className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-full bg-primary/20 text-primary">
              <Sparkles size={24} />
            </div>
            <p className="font-display text-2xl font-black text-foreground">
              Despegue confirmado.
            </p>
            <p className="mt-3 text-muted-foreground max-w-md mx-auto font-medium">
              Gracias <strong className="text-foreground">{fullName || "piloto"}</strong>. Un especialista en ruta de{" "}
              <strong className="text-foreground">{city}</strong> te contactará en las próximas 24 horas a{" "}
              <strong className="text-foreground">{email}</strong> para coordinar tu{" "}
              <span className="text-primary font-bold">{type.toLowerCase()}</span> de la{" "}
              <strong className="text-foreground">{model}</strong>.
            </p>
            <div className="mt-6">
              <AkButton
                variant="outline"
                onClick={() => {
                  setSent(false);
                  setStep(0);
                }}
              >
                Hacer otra solicitud
              </AkButton>
            </div>
          </div>
        ) : step === 0 ? (
          <div className="mt-6 space-y-5">
            <p className="text-xs font-mono font-bold uppercase tracking-widest text-muted-foreground">
              Paso 1 · Elige tu máquina
            </p>
            <div className="grid gap-3 sm:grid-cols-2">
              {bikes.map((b) => (
                <button
                  type="button"
                  key={b.name}
                  onClick={() => {
                    sound.playMechanicalClick();
                    setModel(b.name);
                  }}
                  className={cn(
                    "flex items-center gap-3 rounded-xl border-2 p-4 text-left transition-all cursor-pointer bg-card",
                    model === b.name
                      ? "border-primary bg-primary/10 shadow-md"
                      : "border-border hover:border-foreground/50"
                  )}
                >
                  <img src={b.img} alt={b.name} className="h-10 w-14 object-contain" />
                  <div>
                    <p className="font-display font-black text-foreground">{b.name}</p>
                    <p className="text-xs text-muted-foreground font-semibold">
                      {b.cat} · {b.cc}
                    </p>
                  </div>
                </button>
              ))}
            </div>
            <div className="pt-2">
              <AkButton
                type="button"
                disabled={!model}
                onClick={() => setStep(1)}
                className="gap-2"
              >
                Continuar a Datos <ArrowRight size={16} />
              </AkButton>
            </div>
          </div>
        ) : (
          <form
            className="mt-6 space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              setSent(true);
            }}
          >
            <div className="flex items-center justify-between">
              <p className="text-xs font-mono font-bold uppercase tracking-widest text-muted-foreground">
                Paso 2 · Concesionario y solicitud para {model}
              </p>
              <button
                type="button"
                onClick={() => setStep(0)}
                className="text-xs text-primary underline underline-offset-4 cursor-pointer font-bold"
              >
                Cambiar moto
              </button>
            </div>

            <div className="relative">
              <MapPin
                size={16}
                className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"
              />
              <select
                required
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className={cn(inputClass, "pl-11 cursor-pointer")}
              >
                <option value="">Selecciona concesionario oficial</option>
                {cities.map((c) => (
                  <option key={c} value={c}>
                    Akira Center {c}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex gap-2">
              {["Test Drive", "Cotización"].map((t) => (
                <button
                  type="button"
                  key={t}
                  onClick={() => {
                    sound.playMechanicalClick();
                    setType(t);
                  }}
                  className={cn(
                    "clip-cyber-corner flex-1 border-2 py-3 text-xs sm:text-sm font-bold uppercase tracking-wider transition-colors cursor-pointer",
                    type === t
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border bg-card text-muted-foreground hover:border-foreground hover:text-foreground"
                  )}
                >
                  {t}
                </button>
              ))}
            </div>

            <input
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Nombre completo"
              maxLength={80}
              className={inputClass}
            />
            <input
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Correo electrónico (ej. nombre@correo.com)"
              maxLength={120}
              className={inputClass}
            />

            <div className="flex gap-3 pt-2">
              <AkButton
                type="button"
                variant="outline"
                onClick={() => setStep(0)}
              >
                Atrás
              </AkButton>
              <AkButton type="submit">
                Confirmar {type}
              </AkButton>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

export function Footer() {
  const [subscribed, setSubscribed] = useState(false);
  const [subEmail, setSubEmail] = useState("");

  return (
    <footer className="border-t-2 border-border bg-card">
      <div className="mx-auto grid max-w-6xl gap-10 px-6 py-16 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2">
            <img
              src={logoImg}
              alt="Akira Motors"
              className="akira-brand-logo h-8 w-auto object-contain"
            />
            <span className="font-display font-black text-sm tracking-wider text-foreground">
              AKIRA <span className="text-primary font-bold">MOTORS</span>
            </span>
          </div>
          <p className="mt-3 text-sm font-medium text-muted-foreground leading-relaxed">
            Supera el límite de lo convencional. Potencia y diseño sin concesiones.
          </p>
          <div className="mt-5 flex gap-3">
            {[Instagram, Youtube, Facebook].map((IconComp, i) => (
              <a
                key={i}
                href="#"
                aria-label="Red social"
                className="grid h-9 w-9 place-items-center rounded-lg border border-border text-muted-foreground hover:border-primary hover:text-primary transition-colors bg-background"
              >
                <IconComp size={16} />
              </a>
            ))}
          </div>
        </div>

        <div>
          <p className="mb-3 text-xs uppercase tracking-widest text-muted-foreground font-black">
            Mapa del sitio
          </p>
          {[
            ["AKR 1390", "akr1390"],
            ["Catálogo", "catalogo"],
            ["Experiencia", "experiencia"],
            ["Concesionarios", "contacto"],
          ].map(([label, id]) => (
            <p key={id} className="py-1">
              <button
                type="button"
                onClick={() => goTo(id)}
                className="text-sm font-bold text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
              >
                {label}
              </button>
            </p>
          ))}
        </div>

        <div>
          <p className="mb-3 text-xs uppercase tracking-widest text-muted-foreground font-black">
            Talleres y Concesionarios
          </p>
          {cities.map((c) => (
            <p key={c} className="py-1 text-sm font-medium text-muted-foreground">
              {c} · Concesionario Oficial
            </p>
          ))}
        </div>

        <div>
          <p className="mb-3 text-xs uppercase tracking-widest text-muted-foreground font-black">
            Novedades Exclusivas
          </p>
          {subscribed ? (
            <p className="text-sm text-primary font-black">
              ¡Gracias por suscribirte al club Akira!
            </p>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (subEmail) setSubscribed(true);
              }}
            >
              <input
                type="email"
                required
                value={subEmail}
                onChange={(e) => setSubEmail(e.target.value)}
                placeholder="tu@correo.com"
                className="w-full rounded-lg border-2 border-input bg-background px-4 py-3 text-sm outline-none focus:border-primary text-foreground font-medium"
              />
              <AkButton className="mt-3 w-full text-xs">Suscribirme</AkButton>
            </form>
          )}
        </div>
      </div>

      <div className="border-t border-border px-6 py-6 text-center text-xs font-medium text-muted-foreground">
        © 2026 Akira Motors · Todos los derechos reservados · Términos · Privacidad · Cookies
      </div>
    </footer>
  );
}
