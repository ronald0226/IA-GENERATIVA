/**
 * Akira Motors Cyberpunk Engine Synthesizer
 * Built exclusively using Web Audio API for zero network dependencies.
 * Complies with brand PDF: "sonido de motor opcional con precisión mecánica".
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private currentIdleGain: GainNode | null = null;

  constructor() {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("akira_audio_muted");
      this.isMuted = saved === "true";
    }
  }

  private initCtx() {
    if (!this.ctx && typeof window !== "undefined") {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume();
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
    if (typeof window !== "undefined") {
      localStorage.setItem("akira_audio_muted", String(muted));
    }
  }

  public toggleMute(): boolean {
    const next = !this.isMuted;
    this.setMuted(next);
    if (!next) {
      this.playMechanicalClick();
    }
    return next;
  }

  /**
   * Sharp cyberpunk tactile click for buttons and tabs
   */
  public playMechanicalClick(): void {
    if (this.isMuted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = "sine";
      osc.frequency.setValueAtTime(1200, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(300, this.ctx.currentTime + 0.04);

      gain.gain.setValueAtTime(0.08, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.04);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.045);
    } catch {
      // Audio autoplay policy fallback
    }
  }

  /**
   * Visceral twin-cylinder motorcycle engine rev up
   * Inspired by Kaneda's high-efficiency twin-rotor bike in AKIRA (1988)
   */
  public playEngineRev(targetRpmRatio = 1.0): void {
    if (this.isMuted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const duration = 1.2;

      // Sub-rumble oscillator (V-twin cylinder thump)
      const oscLow = this.ctx.createOscillator();
      const oscMid = this.ctx.createOscillator();
      const filter = this.ctx.createBiquadFilter();
      const gain = this.ctx.createGain();

      oscLow.type = "sawtooth";
      oscMid.type = "triangle";

      // Pitch ramp simulates RPM soaring
      const baseFreq = 48;
      const peakFreq = baseFreq + 130 * targetRpmRatio;

      oscLow.frequency.setValueAtTime(baseFreq, now);
      oscLow.frequency.exponentialRampToValueAtTime(peakFreq, now + 0.4);
      oscLow.frequency.exponentialRampToValueAtTime(baseFreq * 1.1, now + duration);

      oscMid.frequency.setValueAtTime(baseFreq * 2, now);
      oscMid.frequency.exponentialRampToValueAtTime(peakFreq * 1.8, now + 0.4);
      oscMid.frequency.exponentialRampToValueAtTime(baseFreq * 2.2, now + duration);

      // Lowpass resonant filter sweeps with throttle opening
      filter.type = "lowpass";
      filter.frequency.setValueAtTime(280, now);
      filter.frequency.exponentialRampToValueAtTime(1400, now + 0.38);
      filter.frequency.exponentialRampToValueAtTime(320, now + duration);
      filter.Q.setValueAtTime(3.5, now);

      // Gain envelope with throttle burst and exhaust pop
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.18, now + 0.15);
      gain.gain.exponentialRampToValueAtTime(0.14, now + 0.5);
      gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

      oscLow.connect(filter);
      oscMid.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      oscLow.start(now);
      oscMid.start(now);
      oscLow.stop(now + duration);
      oscMid.stop(now + duration);
    } catch {
      // Audio autoplay policy fallback
    }
  }

  /**
   * Subtle hover roar when mouse hovers over motorcycle cards
   */
  public playHoverRumble(): void {
    if (this.isMuted) return;
    try {
      this.initCtx();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const duration = 0.35;

      const osc = this.ctx.createOscillator();
      const filter = this.ctx.createBiquadFilter();
      const gain = this.ctx.createGain();

      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(52, now);
      osc.frequency.exponentialRampToValueAtTime(88, now + 0.15);
      osc.frequency.exponentialRampToValueAtTime(55, now + duration);

      filter.type = "lowpass";
      filter.frequency.setValueAtTime(350, now);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.06, now + 0.08);
      gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + duration);
    } catch {
      // Audio policy
    }
  }
}

export const sound = new SoundEngine();
