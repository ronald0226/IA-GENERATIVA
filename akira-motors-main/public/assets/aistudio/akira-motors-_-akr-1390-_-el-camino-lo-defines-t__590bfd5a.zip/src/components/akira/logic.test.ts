import test from "node:test";
import assert from "node:assert/strict";
import {
  filterBikesByCategory,
  findBikeBySlug,
  toggleCompareList,
  calculatePowerToWeightRatio,
  validateBuyerForm,
} from "./logic";
import { bikes } from "./data";

test("filterBikesByCategory returns all bikes when category is Todas", () => {
  const all = filterBikesByCategory(bikes, "Todas");
  assert.equal(all.length, bikes.length);
});

test("filterBikesByCategory filters correctly by specific category", () => {
  const nakedBikes = filterBikesByCategory(bikes, "Naked");
  assert.equal(nakedBikes.length, 1);
  assert.equal(nakedBikes[0].name, "AKR 1390");

  const adventureBikes = filterBikesByCategory(bikes, "Adventure");
  assert.equal(adventureBikes.length, 1);
  assert.equal(adventureBikes[0].name, "AKR 990R");
});

test("findBikeBySlug locates bike by exact slug and verifies updated tech specs", () => {
  const bike = findBikeBySlug(bikes, "akr-1390");
  assert.ok(bike);
  assert.equal(bike?.name, "AKR 1390");
  assert.equal(bike?.hp, "180 HP");
  assert.ok(bike?.tech && bike.tech.length >= 7);
  assert.equal(bike?.tech[0][0], "ABS");
  assert.equal(bike?.tech[0][1], "Bosch 10.3 Cornering ABS con modo Supermoto");

  const notFound = findBikeBySlug(bikes, "non-existent-bike");
  assert.equal(notFound, undefined);
});

test("toggleCompareList adds, caps at max 2, and removes correctly", () => {
  let list: string[] = [];
  list = toggleCompareList(list, "AKR 1390");
  assert.deepEqual(list, ["AKR 1390"]);

  list = toggleCompareList(list, "AKR 990R");
  assert.deepEqual(list, ["AKR 1390", "AKR 990R"]);

  // Adding 3rd drops the first to keep max 2
  list = toggleCompareList(list, "AKR 790");
  assert.deepEqual(list, ["AKR 990R", "AKR 790"]);

  // Clicking an already selected item removes it
  list = toggleCompareList(list, "AKR 790");
  assert.deepEqual(list, ["AKR 990R"]);
});

test("calculatePowerToWeightRatio parses strings and calculates ratio accurately", () => {
  const ratio = calculatePowerToWeightRatio("180 HP", "199 kg");
  assert.equal(ratio, 0.9);

  const mxRatio = calculatePowerToWeightRatio("63 HP", "104 kg");
  assert.equal(mxRatio, 0.61);
});

test("validateBuyerForm validates all required fields, document regex and terminos", () => {
  const emptyResult = validateBuyerForm({
    nombre: "",
    documento: "",
    email: "",
    telefono: "",
    ciudad: "",
    direccion: "",
    terminos: false,
  });
  assert.ok(emptyResult.nombre);
  assert.ok(emptyResult.documento);
  assert.ok(emptyResult.email);
  assert.ok(emptyResult.telefono);
  assert.ok(emptyResult.ciudad);
  assert.ok(emptyResult.direccion);
  assert.ok(emptyResult.terminos);

  const invalidDoc = validateBuyerForm({
    nombre: "Juan Perez",
    documento: "abc12",
    email: "correo@invalido",
    telefono: "123",
    ciudad: "Bogotá",
    direccion: "Calle 100",
    terminos: true,
  });
  assert.ok(invalidDoc.documento);
  assert.ok(invalidDoc.email);
  assert.ok(invalidDoc.telefono);
  assert.equal(invalidDoc.nombre, undefined);
  assert.equal(invalidDoc.ciudad, undefined);
  assert.equal(invalidDoc.direccion, undefined);
  assert.equal(invalidDoc.terminos, undefined);

  const validResult = validateBuyerForm({
    nombre: "Juan Perez",
    documento: "1020304050",
    email: "juan@example.com",
    telefono: "+57 300 1234567",
    ciudad: "Bogotá",
    direccion: "Carrera 15 # 93-60",
    terminos: true,
  });
  assert.deepEqual(validResult, {});
});
