import { bikes, type Category, type Bike } from "./data";

export function filterBikesByCategory(
  allBikes: Bike[],
  category: "Todas" | Category
): Bike[] {
  if (category === "Todas") {
    return allBikes;
  }
  return allBikes.filter((bike) => bike.cat === category);
}

export function findBikeBySlug(allBikes: Bike[], slug: string): Bike | undefined {
  return allBikes.find((bike) => bike.slug === slug);
}

export function toggleCompareList(
  currentList: string[],
  bikeName: string,
  maxCompare = 2
): string[] {
  if (currentList.includes(bikeName)) {
    return currentList.filter((name) => name !== bikeName);
  }
  return [...currentList, bikeName].slice(-maxCompare);
}

export function calculatePowerToWeightRatio(hpStr: string, kgStr: string): number {
  const hp = parseFloat(hpStr.replace(/[^0-9.]/g, ""));
  const kg = parseFloat(kgStr.replace(/[^0-9.]/g, ""));
  if (isNaN(hp) || isNaN(kg) || kg <= 0) return 0;
  return Number((hp / kg).toFixed(2));
}

export interface BuyerFormInput {
  nombre: string;
  documento: string;
  email: string;
  telefono: string;
  ciudad: string;
  direccion: string;
  terminos: boolean;
}

export function validateBuyerForm(input: BuyerFormInput): Record<string, string> {
  const errors: Record<string, string> = {};
  if (!input.nombre.trim() || input.nombre.trim().length < 2) {
    errors.nombre = "Escribe tu nombre completo";
  }
  if (!input.documento.trim() || !/^[0-9]{5,12}$/.test(input.documento.trim())) {
    errors.documento = "Documento inválido (solo números de 5 a 12 dígitos)";
  }
  if (
    !input.email.trim() ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.email.trim())
  ) {
    errors.email = "Correo inválido";
  }
  if (
    !input.telefono.trim() ||
    !/^[0-9+ ]{7,15}$/.test(input.telefono.trim())
  ) {
    errors.telefono = "Teléfono inválido";
  }
  if (!input.ciudad) {
    errors.ciudad = "Elige una ciudad";
  }
  if (!input.direccion.trim() || input.direccion.trim().length < 5) {
    errors.direccion = "Escribe tu dirección";
  }
  if (!input.terminos) {
    errors.terminos = "Debes aceptar los términos y condiciones";
  }
  return errors;
}
