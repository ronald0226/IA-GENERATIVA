<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Estrella guía

Los pilotos encuentran su moto Akira y llegan a manejarla.

## Métrica

Personas que solicitan un test drive cada semana
