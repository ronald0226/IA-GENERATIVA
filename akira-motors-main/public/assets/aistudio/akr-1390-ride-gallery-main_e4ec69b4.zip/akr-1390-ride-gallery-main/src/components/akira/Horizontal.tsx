import { useEffect, useRef, useState, type ReactNode } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ArrowRight } from "lucide-react";
import bike from "@/assets/akr1390-hero.png.asset.json";
import { Specs, Catalog, Brand, Contact } from "./Sections";

export const PANELS = ["inicio", "akr1390", "catalogo", "experiencia", "contacto"] as const;

/** Scroll target for each panel, filled once the timeline is built. */
export const panelScroll: Record<string, number> = {};

export function goTo(id: string) {
  const y = panelScroll[id];
  if (y !== undefined) window.scrollTo({ top: y, behavior: "smooth" });
  else document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
}

function Panel({ id, children, className = "" }: { id: string; children: ReactNode; className?: string }) {
  return (
    <section id={id} className={`relative flex min-h-[100svh] w-full shrink-0 items-center overflow-hidden lg:h-screen lg:min-h-0 lg:w-screen ${className}`}>
      {children}
    </section>
  );
}

export function HorizontalPage() {
  const wrap = useRef<HTMLDivElement>(null);
  const track = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const mm = gsap.matchMedia();
    mm.add("(min-width: 1024px)", () => {
      const n = PANELS.length;
      // Timeline units: bike entry (1) + hold (0.4), then per section: move (1) + hold (0.6)
      const tl = gsap.timeline({ defaults: { ease: "none" } });
      tl.addLabel("inicio", 0);
      tl.fromTo("[data-bike]", { xPercent: -130, opacity: 0 }, { xPercent: 0, opacity: 1, duration: 1, ease: "power2.out" });
      tl.fromTo("[data-hint]", { opacity: 1 }, { opacity: 0, duration: 0.3 }, 0);
      tl.to({}, { duration: 0.4 });
      for (let i = 1; i < n; i++) {
        tl.to(track.current, { xPercent: (-100 * i) / n, duration: 1, ease: "power2.inOut" });
        tl.addLabel(PANELS[i]!);
        tl.to({}, { duration: 0.6 });
      }
      const st = ScrollTrigger.create({
        trigger: wrap.current,
        pin: true,
        animation: tl,
        scrub: 0.8,
        start: "top top",
        end: () => "+=" + window.innerHeight * tl.duration() * 1.2,
        invalidateOnRefresh: true,
        onUpdate: (s) => setProgress(s.progress),
        onRefresh: (s) => {
          PANELS.forEach((p) => {
            const t = p === "inicio" ? 0 : (tl.labels[p] ?? 0) + 0.3;
            panelScroll[p] = s.start + (s.end - s.start) * (t / tl.duration());
          });
        },
      });
      return () => {
        st.kill();
        PANELS.forEach((p) => delete panelScroll[p]);
      };
    });
    gsap.from("[data-intro]", { y: 60, opacity: 0, stagger: 0.12, duration: 1, ease: "power3.out" });
    return () => mm.revert();
  }, []);

  return (
    <div ref={wrap} className="relative lg:h-screen lg:overflow-hidden">
      <div ref={track} className="flex flex-col lg:h-full lg:w-[500vw] lg:flex-row">
        {/* 1 · Página principal: moto a la izquierda, texto a la derecha */}
        <Panel id="inicio">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_30%_60%,color-mix(in_oklab,var(--color-primary)_22%,transparent),transparent_60%)]" />
          <div className="relative grid w-full items-center gap-6 px-6 pt-28 pb-12 lg:grid-cols-[1.3fr_1fr] lg:px-16 lg:pt-16 lg:pb-0">
            <img
              data-bike
              src={bike.url}
              alt="Moto Akira AKR 1390 blanca y roja"
              width={1620}
              height={970}
              className="order-2 w-full drop-shadow-[0_40px_60px_rgba(0,0,0,0.6)] lg:order-1 lg:max-h-[70vh] lg:object-contain"
            />
            <div className="order-1 lg:order-2">
              <p data-intro className="text-xs font-semibold uppercase tracking-[0.4em] text-primary">Akira Motors presenta</p>
              <h1 data-intro className="font-display text-[clamp(3.5rem,10vw,9rem)] font-black leading-[0.85] tracking-tight">
                AKR
                <br />
                <span className="text-transparent [-webkit-text-stroke:2px_var(--color-foreground)]">1390</span>
              </h1>
              <p data-intro className="mt-6 max-w-sm text-lg text-muted-foreground">
                El camino no está trazado. <strong className="text-foreground">Lo defines tú.</strong>
              </p>
              <button
                data-intro
                onClick={() => goTo("akr1390")}
                className="mt-8 inline-flex items-center gap-3 rounded-lg bg-primary px-6 py-3 text-sm font-semibold uppercase tracking-wider text-primary-foreground hover:bg-primary-deep"
              >
                Desbloquea la AKR 1390 <ArrowRight size={18} />
              </button>
            </div>
          </div>
          <p data-hint className="absolute bottom-14 left-16 hidden items-center gap-3 text-sm text-muted-foreground lg:flex">
            Haz scroll hacia abajo para explorar <ArrowRight className="animate-pulse text-primary" size={18} />
          </p>
        </Panel>

        <Panel id="akr1390"><Specs /></Panel>
        <Panel id="catalogo" className="bg-card"><Catalog /></Panel>
        <Panel id="experiencia"><Brand /></Panel>
        <Panel id="contacto" className="bg-card"><Contact /></Panel>
      </div>

      {/* Indicador de progreso horizontal */}
      <div className="pointer-events-none absolute inset-x-16 bottom-6 hidden items-center gap-4 lg:flex">
        <div className="h-0.5 flex-1 bg-border">
          <div className="h-full bg-primary" style={{ width: `${progress * 100}%` }} />
        </div>
        <span className="font-display text-xs font-bold tabular-nums">
          0{Math.min(PANELS.length, Math.round(progress * (PANELS.length - 1)) + 1)} / 0{PANELS.length}
        </span>
      </div>
    </div>
  );
}
