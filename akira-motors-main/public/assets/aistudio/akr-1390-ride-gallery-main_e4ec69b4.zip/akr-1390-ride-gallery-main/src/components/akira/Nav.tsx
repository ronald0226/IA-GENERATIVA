import { useEffect, useState } from "react";
import { Moon, Sun, Menu, X } from "lucide-react";
import { AkButton } from "./ui";
import { goTo } from "./Horizontal";
import logo from "@/assets/akira-logo.png.asset.json";

const links = [
  ["AKR 1390", "#akr1390"],
  ["Catálogo", "#catalogo"],
  ["Experiencia", "#experiencia"],
  ["Concesionarios", "#contacto"],
];

export function Nav() {
  const [light, setLight] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    document.documentElement.classList.toggle("light", light);
  }, [light]);

  return (
    <header className="fixed inset-x-0 top-4 z-50 px-4">
      <nav className="mx-auto flex max-w-6xl items-center justify-between rounded-2xl border border-border bg-background/60 px-5 py-3 backdrop-blur-xl">
        <a href="#inicio" onClick={(e) => { e.preventDefault(); goTo("inicio"); }} className="font-display text-xl font-black tracking-tight">
          <img src={logo.url} alt="Akira Motors" className="h-7 w-auto" />
        </a>
        <ul className="hidden items-center gap-8 lg:flex">
          {links.map(([l, h]) => (
            <li key={h}>
              <a href={h} onClick={(e) => { e.preventDefault(); goTo((h ?? "").slice(1)); }} className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                {l}
              </a>
            </li>
          ))}
        </ul>
        <div className="flex items-center gap-2">
          <button
            aria-label="Cambiar tema"
            onClick={() => setLight((v) => !v)}
            className="grid h-10 w-10 place-items-center rounded-lg border border-border hover:border-primary"
          >
            {light ? <Moon size={18} /> : <Sun size={18} />}
          </button>
          <a href="#contacto" onClick={(e) => { e.preventDefault(); goTo("contacto"); }} className="hidden sm:block">
            <AkButton className="px-4 py-2.5">Agenda tu Test Drive</AkButton>
          </a>
          <button aria-label="Menú" onClick={() => setOpen((v) => !v)} className="grid h-10 w-10 place-items-center lg:hidden">
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </nav>
      {open && (
        <ul className="mx-auto mt-2 max-w-6xl space-y-1 rounded-2xl border border-border bg-background/90 p-4 backdrop-blur-xl lg:hidden">
          {[...links, ["Agenda tu Test Drive", "#contacto"]].map(([l, h]) => (
            <li key={l}>
              <a href={h} onClick={(e) => { e.preventDefault(); setOpen(false); goTo((h ?? "").slice(1)); }} className="block rounded-lg px-3 py-2 hover:bg-muted">
                {l}
              </a>
            </li>
          ))}
        </ul>
      )}
    </header>
  );
}
