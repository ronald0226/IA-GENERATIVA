import { useState } from "react";
import { ChevronDown, GitCompare, Check, Instagram, Youtube, Facebook, MapPin } from "lucide-react";
import { AkButton, Eyebrow, SectionTitle } from "./ui";
import { bikes, categories, cities } from "./data";
import { cn } from "@/lib/utils";
import { Link } from "@tanstack/react-router";
import logo from "@/assets/akira-logo.png.asset.json";
import road from "@/assets/akr1390.jpg";

const specs = [
  { k: "Cilindrada", v: "1390", u: "cc", d: "Bicilíndrico en V a 75°, refrigerado por líquido." },
  { k: "Potencia", v: "180", u: "HP", d: "A 10.000 rpm. Empuje lineal hasta el corte." },
  { k: "Torque", v: "145", u: "Nm", d: "A 8.000 rpm. Aceleración que se siente en el pecho." },
  { k: "Peso", v: "199", u: "kg", d: "En orden de marcha, sin combustible." },
  { k: "Modos", v: "4", u: "modos", d: "Rain · Street · Sport · Track, con telemetría en TFT." },
];

export function Specs() {
  const [open, setOpen] = useState(0);
  return (
    <div className="mx-auto w-full max-w-6xl px-6 py-24 lg:px-16 lg:py-0">
      <div className="grid gap-12 lg:grid-cols-[1fr_1.2fr]">
        <div>
          <Eyebrow>Ficha técnica</Eyebrow>
          <SectionTitle>Siente la potencia</SectionTitle>
          <p className="mt-6 max-w-md text-muted-foreground">
            Rendimiento calibrado para quienes no se conforman. Cada número es una sensación al mando.
          </p>
        </div>
        <ul className="divide-y divide-border border-y border-border">
          {specs.map((s, i) => (
            <li key={s.k}>
              <button onClick={() => setOpen(i === open ? -1 : i)} className="flex w-full items-center justify-between py-3 text-left">
                <span className="text-sm uppercase tracking-widest text-muted-foreground">{s.k}</span>
                <span className="flex items-center gap-4">
                  <span className="font-display text-3xl font-black">
                    {s.v}<span className="ml-1 text-sm font-semibold text-primary">{s.u}</span>
                  </span>
                  <ChevronDown size={18} className={cn("transition-transform", open === i && "rotate-180 text-primary")} />
                </span>
              </button>
              <div className={cn("grid transition-all duration-500", open === i ? "grid-rows-[1fr] pb-5" : "grid-rows-[0fr]")}>
                <p className="overflow-hidden text-sm font-light text-muted-foreground">{s.d}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export function Catalog() {
  const [cat, setCat] = useState<(typeof categories)[number]>("Todas");
  const [compare, setCompare] = useState<string[]>([]);
  const list = bikes.filter((b) => cat === "Todas" || b.cat === cat);
  return (
    <div className="w-full py-24 lg:pt-16 lg:pb-0">
      <div className="mx-auto max-w-6xl px-6">
        <div className="flex flex-col justify-between gap-8 md:flex-row md:items-end">
          <div>
            <Eyebrow>Catálogo</Eyebrow>
            <SectionTitle>Elige tu territorio</SectionTitle>
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={cn(
                  "rounded-full border px-4 py-2 text-sm transition-colors",
                  cat === c ? "border-primary bg-primary text-primary-foreground" : "border-border hover:border-foreground",
                )}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {list.map((b) => {
            const on = compare.includes(b.name);
            return (
              <article key={b.name} className="group overflow-hidden rounded-2xl border border-border bg-background">
                <Link to="/motos/$slug" params={{ slug: b.slug }} className="relative block aspect-[4/3] overflow-hidden">
                  <img src={b.img} alt={`Moto ${b.name}`} loading="lazy" className="h-full w-full object-contain p-3 transition-transform duration-700 group-hover:scale-110 group-hover:-rotate-1" />
                  <span className="absolute left-4 top-4 rounded-full bg-background/70 px-3 py-1 text-xs uppercase tracking-widest backdrop-blur">{b.cat}</span>
                  <div className="absolute inset-x-0 bottom-0 flex translate-y-full justify-around bg-background/85 py-4 backdrop-blur transition-transform duration-500 group-hover:translate-y-0">
                    {[b.cc, b.hp, b.kg].map((v) => (
                      <span key={v} className="font-display text-sm font-bold">{v}</span>
                    ))}
                  </div>
                </Link>
                <div className="flex flex-col items-start gap-3 p-4">
                  <h3 className="font-display text-lg font-black">{b.name}</h3>
                  <p className="text-sm text-muted-foreground">{b.price}</p>
                  <div className="flex w-full flex-wrap gap-2">
                  <Link to="/motos/$slug" params={{ slug: b.slug }} className="rounded-lg bg-primary px-3 py-2 text-xs font-semibold uppercase tracking-wider text-primary-foreground hover:bg-primary-deep">
                    Comprar
                  </Link>
                  <button
                    onClick={() => setCompare((c) => (on ? c.filter((n) => n !== b.name) : [...c, b.name].slice(-2)))}
                    className={cn("flex items-center gap-2 rounded-lg border px-3 py-2 text-xs uppercase tracking-wider", on ? "border-primary text-primary" : "border-border")}
                  >
                    {on ? <Check size={14} /> : <GitCompare size={14} />} Comparar
                  </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
        {compare.length === 2 && (
          <div className="mt-4 grid grid-cols-3 gap-4 rounded-2xl border border-primary p-4 text-sm">
            <span className="text-muted-foreground">Comparación</span>
            {compare.map((n) => {
              const b = bikes.find((x) => x.name === n)!;
              return (
                <div key={n}>
                  <p className="font-display font-black">{n}</p>
                  <p className="text-muted-foreground">{b.cc} · {b.hp} · {b.kg}</p>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

export function Brand() {
  return (
    <div className="relative flex h-full min-h-[100svh] w-full items-center overflow-hidden py-24 lg:min-h-0 lg:py-0">
      <img src={road} alt="" aria-hidden loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-30" />
      <div className="absolute inset-0 bg-linear-to-b from-background via-background/40 to-background" />
      <div className="relative mx-auto max-w-4xl px-6 text-center">
        <Eyebrow>ADN Akira</Eyebrow>
        <p className="font-display text-[clamp(1.6rem,3.6vw,3rem)] font-black uppercase leading-tight">
          No construimos vehículos para encajar en la ciudad. Diseñamos <span className="text-primary">máquinas para redibujar el mapa.</span>
        </p>
        <p className="mx-auto mt-8 max-w-xl font-light text-muted-foreground">
          Cada curva es un reto y cada aceleración es una declaración de libertad. La potencia está ahí, el control es tuyo. Explora lo inexplorado.
        </p>
        <div className="mt-10 grid grid-cols-3 gap-6">
          {[["12", "años en ruta"], ["48", "países"], ["210K", "pilotos"]].map(([n, l]) => (
            <div key={l}>
              <p className="font-display text-4xl font-black text-sand">{n}</p>
              <p className="text-xs uppercase tracking-widest text-muted-foreground">{l}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function Contact() {
  const [step, setStep] = useState(0);
  const [model, setModel] = useState("");
  const [city, setCity] = useState("");
  const [type, setType] = useState("Test Drive");
  const [sent, setSent] = useState(false);
  const input = "w-full rounded-lg border border-input bg-background px-4 py-3 outline-none focus:border-primary";
  return (
    <div className="mx-auto w-full max-w-3xl px-6 py-24 lg:py-0">
      <div>
        <Eyebrow>Concesionarios</Eyebrow>
        <SectionTitle>Configura tu ruta</SectionTitle>
        <div className="mt-6 flex gap-2">
          {[0, 1].map((i) => (
            <span key={i} className={cn("h-1 flex-1 rounded-full", step >= i ? "bg-primary" : "bg-border")} />
          ))}
        </div>
        {sent ? (
          <div className="mt-10 rounded-2xl border border-primary p-8 text-center">
            <p className="font-display text-2xl font-black">Despegue confirmado.</p>
            <p className="mt-2 text-muted-foreground">Un especialista en ruta de {city} te contactará para tu {type.toLowerCase()} de la {model}.</p>
          </div>
        ) : step === 0 ? (
          <div className="mt-6 space-y-5">
            <p className="text-sm uppercase tracking-widest text-muted-foreground">1 · Elige tu máquina</p>
            <div className="grid gap-3 sm:grid-cols-2">
              {bikes.map((b) => (
                <button key={b.name} onClick={() => setModel(b.name)} className={cn("rounded-xl border p-4 text-left transition-colors", model === b.name ? "border-primary bg-primary/10" : "border-border hover:border-foreground")}>
                  <p className="font-display font-black">{b.name}</p>
                  <p className="text-xs text-muted-foreground">{b.cat}</p>
                </button>
              ))}
            </div>
            <AkButton disabled={!model} onClick={() => setStep(1)}>Continuar</AkButton>
          </div>
        ) : (
          <form className="mt-6 space-y-3" onSubmit={(e) => { e.preventDefault(); setSent(true); }}>
            <p className="text-sm uppercase tracking-widest text-muted-foreground">2 · Ciudad y solicitud</p>
            <div className="relative">
              <MapPin size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <select required value={city} onChange={(e) => setCity(e.target.value)} className={cn(input, "pl-10")}>
                <option value="">Selecciona ciudad / concesionario</option>
                {cities.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="flex gap-2">
              {["Test Drive", "Cotización"].map((t) => (
                <button type="button" key={t} onClick={() => setType(t)} className={cn("flex-1 rounded-lg border py-3 text-sm", type === t ? "border-primary text-primary" : "border-border")}>{t}</button>
              ))}
            </div>
            <input required placeholder="Nombre completo" maxLength={80} className={input} />
            <input required type="email" placeholder="Correo electrónico" maxLength={120} className={input} />
            <div className="flex gap-3 pt-2">
              <AkButton type="button" variant="outline" onClick={() => setStep(0)}>Atrás</AkButton>
              <AkButton type="submit">Agenda tu Test Drive</AkButton>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto grid max-w-6xl gap-10 px-6 py-16 md:grid-cols-4">
        <div>
          <img src={logo.url} alt="Akira Motors" className="h-10 w-auto" />
          <p className="mt-3 text-sm font-light text-muted-foreground">Supera el límite de lo convencional.</p>
          <div className="mt-5 flex gap-3">
            {[Instagram, Youtube, Facebook].map((I, i) => (
              <a key={i} href="#" aria-label="Red social" className="grid h-9 w-9 place-items-center rounded-lg border border-border hover:border-primary hover:text-primary"><I size={16} /></a>
            ))}
          </div>
        </div>
        <div>
          <p className="mb-3 text-xs uppercase tracking-widest text-muted-foreground">Mapa del sitio</p>
          {["AKR 1390", "Catálogo", "Experiencia", "Concesionarios"].map((l) => <p key={l} className="py-1 text-sm">{l}</p>)}
        </div>
        <div>
          <p className="mb-3 text-xs uppercase tracking-widest text-muted-foreground">Talleres</p>
          {cities.map((c) => <p key={c} className="py-1 text-sm">{c}</p>)}
        </div>
        <form onSubmit={(e) => e.preventDefault()}>
          <p className="mb-3 text-xs uppercase tracking-widest text-muted-foreground">Novedades</p>
          <input type="email" placeholder="tu@correo.com" className="w-full rounded-lg border border-input bg-background px-4 py-3 text-sm outline-none focus:border-primary" />
          <AkButton className="mt-3 w-full">Suscribirme</AkButton>
        </form>
      </div>
      <div className="border-t border-border px-6 py-6 text-center text-xs text-muted-foreground">
        © 2026 Akira Motors · Términos · Privacidad · Cookies
      </div>
    </footer>
  );
}
