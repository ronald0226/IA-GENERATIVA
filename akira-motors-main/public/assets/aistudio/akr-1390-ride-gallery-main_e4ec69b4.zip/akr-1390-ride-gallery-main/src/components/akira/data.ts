import hero from "@/assets/akr1390-hero.png.asset.json";
import enduro from "@/assets/akira-590n-enduro.png.asset.json";
import motocross from "@/assets/akira-790-motocross.png.asset.json";
import adventure from "@/assets/akira-990r-adventure.png.asset.json";

export type Category = "Naked" | "Enduro" | "Motocross" | "Adventure";

export type Bike = {
  slug: string;
  name: string;
  cat: Category;
  img: string;
  cc: string;
  hp: string;
  kg: string;
  price: string;
  tagline: string;
  description: string;
  features: string[];
  specs: [string, string][];
};

export const bikes: Bike[] = [
  {
    slug: "akr-1390", name: "AKR 1390", cat: "Naked", img: hero.url, cc: "1390 cc", hp: "180 HP", kg: "199 kg", price: "$ 89.900.000",
    tagline: "La bestia de la ciudad.",
    description: "Nuestra naked insignia. Un bicilíndrico brutal en un chasis ligero, pensado para quien quiere sentir cada aceleración.",
    features: ["Control de tracción en curva", "Quickshifter bidireccional", "Pantalla TFT 5\" con conectividad", "Suspensión WP semiactiva"],
    specs: [["Motor", "Bicilíndrico en V 75°"], ["Cilindrada", "1390 cc"], ["Potencia", "180 HP @ 10.000 rpm"], ["Torque", "145 Nm @ 8.000 rpm"], ["Peso", "199 kg"], ["Tanque", "17,5 L"], ["Altura asiento", "834 mm"], ["Frenos", "Brembo Stylema 320 mm"]],
  },
  {
    slug: "akr-990r", name: "AKR 990R", cat: "Adventure", img: adventure.url, cc: "947 cc", hp: "130 HP", kg: "220 kg", price: "$ 72.500.000",
    tagline: "Explora lo inexplorado.",
    description: "Hecha para cruzar países sin mirar el asfalto. Autonomía, protección y potencia para cualquier terreno.",
    features: ["Modos Rally, Off-road, Street y Rain", "Control crucero adaptativo", "Tanque de gran autonomía", "Protección de motor y manos"],
    specs: [["Motor", "Bicilíndrico paralelo"], ["Cilindrada", "947 cc"], ["Potencia", "130 HP @ 9.500 rpm"], ["Torque", "103 Nm @ 6.750 rpm"], ["Peso", "220 kg"], ["Tanque", "23 L"], ["Altura asiento", "880 mm"], ["Recorrido susp.", "240 mm"]],
  },
  {
    slug: "akr-790", name: "AKR 790", cat: "Motocross", img: motocross.url, cc: "449 cc", hp: "63 HP", kg: "104 kg", price: "$ 48.900.000",
    tagline: "Nacida para volar.",
    description: "Ligera y explosiva. Diseñada para la pista de motocross, con la respuesta que piden los pilotos de competencia.",
    features: ["Launch control", "Chasis de cromo-molibdeno", "Mapas de motor intercambiables", "Arranque eléctrico"],
    specs: [["Motor", "Monocilíndrico 4T"], ["Cilindrada", "449 cc"], ["Potencia", "63 HP"], ["Peso", "104 kg"], ["Tanque", "7,2 L"], ["Altura asiento", "955 mm"], ["Suspensión", "WP XACT 48 mm"], ["Transmisión", "5 velocidades"]],
  },
  {
    slug: "akr-590n", name: "AKR 590N", cat: "Enduro", img: enduro.url, cc: "586 cc", hp: "58 HP", kg: "112 kg", price: "$ 42.300.000",
    tagline: "Del sendero a la ciudad.",
    description: "Enduro versátil y resistente. Va al trabajo entre semana y se pierde en la montaña el fin de semana.",
    features: ["Homologada para calle", "ABS desconectable", "Protector de cárter", "Iluminación LED"],
    specs: [["Motor", "Monocilíndrico 4T"], ["Cilindrada", "586 cc"], ["Potencia", "58 HP"], ["Peso", "112 kg"], ["Tanque", "8,5 L"], ["Altura asiento", "940 mm"], ["Recorrido susp.", "300 mm"], ["Transmisión", "6 velocidades"]],
  },
];

export const categories: ("Todas" | Category)[] = ["Todas", "Naked", "Adventure", "Motocross", "Enduro"];

export const cities = ["Bogotá", "Medellín", "Cali", "Barranquilla", "Bucaramanga"];
