import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";

const variants = {
  primary: "bg-primary text-primary-foreground hover:bg-primary-deep shadow-[0_10px_30px_-10px_var(--color-primary)]",
  dark: "bg-foreground text-background hover:opacity-85",
  outline: "border border-foreground/40 text-foreground hover:border-primary hover:text-primary",
};

export function AkButton({
  variant = "primary",
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: keyof typeof variants }) {
  return (
    <button
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-lg px-6 py-3 text-sm font-semibold uppercase tracking-wider transition-all duration-300 disabled:opacity-40",
        variants[variant],
        className,
      )}
      {...props}
    />
  );
}

export function Eyebrow({ children }: { children: ReactNode }) {
  return (
    <p className="mb-4 flex items-center gap-3 text-xs font-semibold uppercase tracking-[0.3em] text-primary">
      <span className="h-px w-8 bg-primary" />
      {children}
    </p>
  );
}

export function SectionTitle({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <h2 className={cn("font-display text-[clamp(2rem,5vw,4.5rem)] font-black uppercase leading-[0.95]", className)}>
      {children}
    </h2>
  );
}
