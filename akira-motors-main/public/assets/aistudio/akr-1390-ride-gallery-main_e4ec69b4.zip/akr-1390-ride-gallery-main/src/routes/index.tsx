import { createFileRoute } from "@tanstack/react-router";
import { Nav } from "@/components/akira/Nav";
import { HorizontalPage } from "@/components/akira/Horizontal";
import { Footer } from "@/components/akira/Sections";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Akira Motors — AKR 1390 | El camino lo defines tú" },
      { name: "description", content: "Descubre la AKR 1390 y el catálogo Akira Motors: Sport, Naked, Adventure y Urban. Agenda tu test drive." },
      { property: "og:title", content: "Akira Motors — AKR 1390" },
      { property: "og:description", content: "Potencia pura bajo tu mando. Explora la AKR 1390 y agenda tu test drive." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main id="top">
      <Nav />
      <HorizontalPage />
      <Footer />
    </main>
  );
}
