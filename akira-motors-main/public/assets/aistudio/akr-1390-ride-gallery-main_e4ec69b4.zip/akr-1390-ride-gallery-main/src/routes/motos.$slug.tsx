import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, Check } from "lucide-react";
import { bikes } from "@/components/akira/data";
import { AkButton, Eyebrow } from "@/components/akira/ui";
import logo from "@/assets/akira-logo.png.asset.json";

export const Route = createFileRoute("/motos/$slug")({
  loader: ({ params }) => {
    const bike = bikes.find((b) => b.slug === params.slug);
    if (!bike) throw notFound();
    return { bike };
  },
  head: ({ loaderData }) => {
    const b = loaderData?.bike;
    const title = b ? `${b.name} — Akira Motors` : "Moto — Akira Motors";
    const desc = b ? `${b.tagline} ${b.description}` : "Ficha de moto Akira.";
    return {
      meta: [
        { title }, { name: "description", content: desc },
        { property: "og:title", content: title }, { property: "og:description", content: desc },
        { property: "og:type", content: "product" }, { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  notFoundComponent: () => (
    <div className="grid min-h-screen place-items-center"><Link to="/" className="text-primary">Moto no encontrada — volver</Link></div>
  ),
  component: BikePage,
});

function BikePage() {
  const { bike: b } = Route.useLoaderData();
  return (
    <main className="min-h-screen bg-background text-foreground">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <Link to="/"><img src={logo.url} alt="Akira Motors" className="h-8 w-auto" /></Link>
        <Link to="/" hash="catalogo" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft size={16} /> Volver al catálogo
        </Link>
      </header>

      <section className="mx-auto grid max-w-6xl items-center gap-10 px-6 py-10 lg:grid-cols-[1.3fr_1fr]">
        <img src={b.img} alt={`Moto ${b.name}`} className="w-full object-contain drop-shadow-2xl" />
        <div>
          <Eyebrow>{b.cat}</Eyebrow>
          <h1 className="font-display text-[clamp(2.5rem,6vw,5rem)] font-black uppercase leading-none">{b.name}</h1>
          <p className="mt-4 text-xl text-sand">{b.tagline}</p>
          <p className="mt-4 font-light text-muted-foreground">{b.description}</p>
          <p className="mt-8 text-xs uppercase tracking-widest text-muted-foreground">Desde</p>
          <p className="font-display text-3xl font-black">{b.price}</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <AkButton>Comprar ahora</AkButton>
            <Link to="/" hash="contacto"><AkButton variant="outline">Agenda tu Test Drive</AkButton></Link>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl grid-cols-3 gap-4 px-6">
        {[b.cc, b.hp, b.kg].map((v) => (
          <div key={v} className="rounded-2xl border border-border p-6 text-center font-display text-2xl font-black">{v}</div>
        ))}
      </section>

      <section className="mx-auto grid max-w-6xl gap-12 px-6 py-16 lg:grid-cols-2">
        <div>
          <Eyebrow>Características</Eyebrow>
          <ul className="space-y-3">
            {b.features.map((f) => (
              <li key={f} className="flex items-start gap-3"><Check className="mt-0.5 text-primary" size={18} /> {f}</li>
            ))}
          </ul>
        </div>
        <div>
          <Eyebrow>Especificaciones</Eyebrow>
          <dl className="divide-y divide-border rounded-2xl border border-border">
            {b.specs.map(([k, v]) => (
              <div key={k} className="flex justify-between px-5 py-3 text-sm">
                <dt className="text-muted-foreground">{k}</dt><dd className="font-semibold">{v}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>
    </main>
  );
}
